<?php

if($_GET['module']=="santri"){
include "module/santri/santri.php";
}
if($_GET['module']=="tampil"){
include "module/santri/tampil.php";
}
if($_GET['module']=="input_santri"){
include "module/santri/input_santri.php";
}
if($_GET['module']=="santri_det"){
include "module/santri/santri_det.php";
}
if($_GET['module']=="detail_santri"){
include "module/santri/detail_santri.php";
}

if($_GET['module']=="pilih"){
include "module/absen/pilih.php";
}
if($_GET['module']=="pilih_view"){
include "module/absen/pilih_view.php";
}

if($_GET['module']=="input_absen"){
include "module/absen/input_absen.php";
}
if($_GET['module']=="absen"){
include "module/absen/absen.php";
}
if($_GET['module']=="pilih_laporan"){
include "module/laporan/pilih_laporan.php";
}
if($_GET['module']=="laporan"){
include "module/laporan/laporan.php";
}
if($_GET['module']=="user"){
include "module/user/user.php";
}
if($_GET['module']=="input_user"){
include "module/user/input_user.php";
}

if($_GET['module']=="input_guru"){
include "module/guru/input_guru.php";
}
if($_GET['module']=="detail_guru"){
include "module/guru/detail_guru.php";
}
if($_GET['module']=="guru_det"){
include "module/guru/guru_det.php";
}

if($_GET['module']=="guru"){
include "module/guru/guru.php";
}
if($_GET['module']=="tampil_guru"){
include "module/guru/tampil_guru.php";
}
if($_GET['module']=="input_kamar"){
include "module/kamar/input_kamar.php";
}
if($_GET['module']=="kamar"){
include "module/kamar/kamar.php";
}
if($_GET['module']=="input_pondok"){
include "module/pondok/input_pondok.php";
}
if($_GET['module']=="pondok"){
include "module/pondok/pondok.php";
}
?>