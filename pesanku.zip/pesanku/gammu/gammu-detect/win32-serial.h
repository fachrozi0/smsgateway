
extern void win32_serial_detect(void);

