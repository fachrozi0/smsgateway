
extern void udev_detect(void);
