Gammu Zarządzanie wszystkimi telefonami - Instalacja
====================================================

Zobacz docs/manual/project/install.rst dla instrukcji instalacji lub w
rozdziale "Kompilacja Gammu" w Podręczniku Gammu.
