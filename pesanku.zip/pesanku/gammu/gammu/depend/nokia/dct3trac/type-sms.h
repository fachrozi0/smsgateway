{0x01, "7.2.1", "CP-DATA"},
{0x04, "7.2.2", "CP-ACK"},
{0x10, "7.2.3", "CP-ERROR"},
{-1, NULL, NULL}
/* Unused sections
*/
