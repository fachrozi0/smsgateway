Gammu All Mobile Management Utilities - Instalace
=================================================

Více informací o kompilaci nalezete v docs/manual-cs/project/install.rst
nebo si přečtěte kapitolu "Kompilace Gammu" v Manuálu Gammu.
